db_username = "admin"
db_password = "LastOne1*"
db_name = "mainDataBase"
db_endpoint = "maindb.crmxmotjuru4.us-east-1.rds.amazonaws.com"
db_port = 3306
